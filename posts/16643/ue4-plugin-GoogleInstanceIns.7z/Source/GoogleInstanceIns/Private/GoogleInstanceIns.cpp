// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "GoogleInstanceIns.h"

#include "ip_shared.h"

#include "Paths.h"
#include "HAL/FileManager.h"
#include "HAL/PlatformMisc.h"
#include "HAL/PlatformProcess.h"
#include "Interfaces/IPluginManager.h"
#define LOCTEXT_NAMESPACE "FGoogleInstanceInsModule"

void FGoogleInstanceInsModule::StartupModule()
{
	FString LibPath = FPaths::Combine(IPluginManager::Get().FindPlugin("GoogleInstanceIns")->GetBaseDir(),TEXT("ThirdParty/x64/Release"));
	FString AbsPath = IFileManager::Get().ConvertToAbsolutePathForExternalAppForRead(*LibPath);
	UE_LOG(LogTemp, Log, TEXT("lib path:%s"), *LibPath);
	UE_LOG(LogTemp, Log, TEXT("abs path:%s"), *AbsPath);
	FPlatformProcess::AddDllDirectory(*AbsPath);
	FPlatformProcess::PushDllDirectory(*AbsPath);
	UE_LOG(LogTemp, Log, TEXT("ip_get_version_string:%s"), ANSI_TO_TCHAR(ip_get_version_string()));
	
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
}

void FGoogleInstanceInsModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FGoogleInstanceInsModule, GoogleInstanceIns)