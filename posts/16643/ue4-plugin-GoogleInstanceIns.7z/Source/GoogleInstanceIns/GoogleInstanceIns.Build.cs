// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;
using System.IO;

public class GoogleInstanceIns : ModuleRules
{
	public GoogleInstanceIns(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		
		PublicIncludePaths.AddRange(
			new string[] {
				// ... add public include paths required here ...
			}
			);
				
		
		PrivateIncludePaths.AddRange(
			new string[] {
				// ... add other private include paths required here ...
			}
			);
			
		
		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				// ... add other public dependencies that you statically link with here ...
			}
			);
			
		
		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"CoreUObject",
				"Engine",
				"Slate",
				"SlateCore",
                "Projects"
				// ... add private dependencies that you statically link with here ...	
			}
			);
		
		
		DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{
				// ... add any modules that your module loads dynamically here ...
			}
			);
        string ThirdPartyDir = Path.Combine(ModuleDirectory, "../../ThirdParty/x64/Release");
        PublicAdditionalLibraries.Add(Path.Combine(ThirdPartyDir, "ip_shared.lib"));

        string[] dllDeps = {
                    "ip_shared.dll",
                    "libeay32.dll",
                    "ssleay32.dll",
                    "zlib.dll",
                };
        foreach (string dll in dllDeps)
        {
            PublicDelayLoadDLLs.Add(dll);
            string dllPath = Path.Combine(ThirdPartyDir, dll);
            RuntimeDependencies.Add(dllPath);
            System.Console.WriteLine(dllPath);
        }
    }
}
