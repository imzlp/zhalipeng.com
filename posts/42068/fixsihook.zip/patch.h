#ifndef __PATCH__H__
#define __PATCH__H__

int PatchSI(void);

#endif
